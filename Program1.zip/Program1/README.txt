I did not add any bonus features other than the ones needed for the assignment (No Bonus Features)

Controls:
For Player1 or Worm1you can use the regular arrow keys to move. Up is the up key and right is the right key and so on.
Player1 can use the Right ALT key to fire.

For Player2 or Worm2 you can use the WASD keys to move. W is up, D is right and so on.
Player2 can use the Left ALT key to fire.

Both worms should be able to be moved with keypad arrow keys, but I used my laptop for this assignment, so I'm not sure.


